(function () {
  const state = { ready: false, provider: "gamesnacks", sdk: null };
  let firstFrameSent = false;
  let readySent = false;

  function init() {
    if (state.ready) return Promise.resolve(state);
    state.sdk = window.GameSnacks || null;
    if (!state.sdk) return Promise.resolve(state);
    state.ready = true;
    try {
      state.sdk.game?.onPause?.(() => window.dispatchEvent(new CustomEvent("nld:platform-pause")));
      state.sdk.game?.onResume?.(() => window.dispatchEvent(new CustomEvent("nld:platform-resume")));
      state.sdk.audio?.subscribe?.((enabled) => {
        window.dispatchEvent(new CustomEvent(enabled ? "nld:platform-audio-on" : "nld:platform-audio-off"));
      });
    } catch {
      // GameSnacks callbacks are best-effort in local preview.
    }
    return Promise.resolve(state);
  }

  function requestAd(kind, callbacks = {}) {
    return init().then(() => new Promise((resolve) => {
      if (!state.sdk?.ad?.break) {
        callbacks.onUnavailable?.({ provider: state.provider, kind });
        resolve(false);
        return;
      }
      let settled = false;
      let rewarded = kind !== "rewarded";
      const finish = () => {
        if (settled) return;
        settled = true;
        callbacks.onFinish?.();
        resolve(Boolean(rewarded));
      };
      const timeout = setTimeout(finish, kind === "rewarded" ? 120000 : 90000);
      const settle = () => {
        clearTimeout(timeout);
        finish();
      };
      try {
        state.sdk.ad.break({
          type: kind === "rewarded" ? "reward" : "next",
          name: kind === "rewarded" ? "focus_assist" : "run_break",
          beforeReward: (showAdFn) => {
            callbacks.onStart?.();
            if (typeof showAdFn === "function") showAdFn();
          },
          beforeAd: () => callbacks.onStart?.(),
          afterAd: settle,
          adViewed: () => {
            rewarded = true;
            callbacks.onRewarded?.();
          },
          adDismissed: () => {
            rewarded = false;
          },
          adBreakDone: settle,
        });
      } catch (error) {
        clearTimeout(timeout);
        callbacks.onError?.(error);
        resolve(false);
      }
    }));
  }

  function gameplayStart() {
    return init().then(() => {
      signalGameReady();
      return true;
    });
  }

  function gameplayStop() {
    return init().then(() => true);
  }

  function track(eventName, payload = {}) {
    if (eventName !== "run_end") return;
    try {
      const score = Math.max(0, Number(payload.score || 0));
      state.sdk?.score?.update?.(score);
      state.sdk?.game?.gameOver?.();
      if (score > 0) state.sdk?.game?.levelComplete?.(1);
    } catch {
      // GameSnacks telemetry is best-effort.
    }
  }

  function getStoredBestScore(key) {
    return init().then(() => {
      try {
        const value = state.sdk?.storage?.getItem?.(key);
        return Math.max(0, Number(value || 0));
      } catch {
        return 0;
      }
    });
  }

  function setStoredBestScore(key, value) {
    return init().then(() => {
      try {
        state.sdk?.storage?.setItem?.(key, String(Math.max(0, Number(value) || 0)));
        return true;
      } catch {
        return false;
      }
    });
  }

  function adsAllowed() {
    return Boolean(state.ready && state.sdk?.ad?.break);
  }

  function signalFirstFrameReady() {
    if (firstFrameSent) return false;
    firstFrameSent = true;
    try {
      state.sdk?.game?.firstFrameReady?.();
      return true;
    } catch {
      return false;
    }
  }

  function signalGameReady() {
    if (readySent) return false;
    readySent = true;
    try {
      state.sdk?.game?.ready?.();
      return true;
    } catch {
      return false;
    }
  }

  window.NeonLanePlatform = {
    init,
    requestAd,
    gameplayStart,
    gameplayStop,
    getStoredBestScore,
    setStoredBestScore,
    adsAllowed,
    track,
    signalFirstFrameReady,
    signalGameReady,
    state,
  };
  setTimeout(() => init(), 0);
})();
