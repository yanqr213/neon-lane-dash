(function () {
  const state = { ready: true, provider: "clean-portal" };

  function init() {
    return Promise.resolve(state);
  }

  function requestAd(kind, callbacks = {}) {
    callbacks.onUnavailable?.({ provider: state.provider, kind });
    return Promise.resolve(false);
  }

  function gameplayStart() {
    return Promise.resolve(false);
  }

  function gameplayStop() {
    return Promise.resolve(false);
  }

  function adsAllowed() {
    return false;
  }

  function track(eventName, payload = {}) {
    const event = { eventName, payload, at: new Date().toISOString(), provider: state.provider };
    try {
      const events = JSON.parse(localStorage.getItem("neon-lane-dash-events") || "[]");
      events.push(event);
      localStorage.setItem("neon-lane-dash-events", JSON.stringify(events.slice(-50)));
    } catch {
      // Local-only telemetry is best effort in the clean portal build.
    }
  }

  window.NeonLanePlatform = { init, requestAd, gameplayStart, gameplayStop, adsAllowed, track, state };
  setTimeout(() => track("page_view", { target: "game" }), 0);
})();
